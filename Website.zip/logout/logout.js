document.getElementById('logoutButton').addEventListener('click', function() {
    window.location.href = '../login/PowerLink.html';
});
